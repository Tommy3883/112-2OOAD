from config.config import Configuration

config = Configuration()
